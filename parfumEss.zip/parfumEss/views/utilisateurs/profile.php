<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">User Profile</h1>
        <table class="table table-bordered">
            <tbody>
                <tr><?php
// Configuration de la base de données
$host = 'localhost';
$dbname = 'Parfumshop';
$username = 'root';
$password = '';

try {
    // Connexion à la base de données
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ID de l'utilisateur dont vous souhaitez afficher le profil et les commandes
    $id_utilisateur = 1; // Remplacez par l'ID de l'utilisateur souhaité

    // Requête pour récupérer les informations de l'utilisateur
    $stmt_user = $pdo->prepare("
        SELECT nom, prenom, email, telephone, date_naissance
        FROM Utilisateur
        WHERE id_utilisateur = :id_utilisateur
    ");
    $stmt_user->bindParam(':id_utilisateur', $id_utilisateur, PDO::PARAM_INT);
    $stmt_user->execute();
    $user = $stmt_user->fetch(PDO::FETCH_OBJ);

    // Requête pour récupérer les commandes de l'utilisateur
    $stmt_orders = $pdo->prepare("
        SELECT id_commande, quantite, prix, statut, date_creation, mode_paiement
        FROM Commande
        WHERE id_utilisateur = :id_utilisateur
    ");
    $stmt_orders->bindParam(':id_utilisateur', $id_utilisateur, PDO::PARAM_INT);
    $stmt_orders->execute();
    $commandes = $stmt_orders->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    echo 'Erreur de connexion : ' . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">

            <tbody>
                <tr>
                    <th scope="row">Nom</th>
                    <td><?= $user->nom ?></td>
                </tr>
                <tr>
                    <th scope="row">Prénom</th>
                    <td><?= $user->prenom ?></td>
                </tr>
                <tr>
                    <th scope="row">Email</th>
                    <td><?= $user->email ?></td>
                </tr>
                <tr>
                    <th scope="row">Numéro de téléphone</th>
                    <td><?= $user->telephone ?></td>
                </tr>
                <tr>
                    <th scope="row">Date de naissance</th>
                    <td><?= $user->date_naissance ?></td>
                </tr>
            </tbody>
        </table>
    </div>

        <h2 class="mt-5 mb-4">Commandes de l'utilisateur</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID Commande</th>
                    <th>Quantité</th>
                    <th>Prix</th>
                    <th>Statut</th>
                    <th>Date de Création</th>
                    <th>Mode de Paiement</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($commandes)) : ?>
                    <?php foreach ($commandes as $commande) : ?>
                        <tr>
                            <td><?= htmlspecialchars($commande['id_commande']) ?></td>
                            <td><?= htmlspecialchars($commande['quantite']) ?></td>
                            <td><?= htmlspecialchars($commande['prix']) ?></td>
                            <td><?= htmlspecialchars($commande['statut']) ?></td>
                            <td><?= htmlspecialchars($commande['date_creation']) ?></td>
                            <td><?= htmlspecialchars($commande['mode_paiement']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="6">Aucune commande trouvée pour cet utilisateur.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

                    <th scope="row">Nom</th>
                    <td><?= $user->nom ?></td>
                </tr>
                <tr>
                    <th scope="row">Prénom</th>
                    <td><?= $user->prenom ?></td>
                </tr>
                <tr>
                    <th scope="row">Email</th>
                    <td><?= $user->email ?></td>
                </tr>
                <tr>
                    <th scope="row">Numéro de téléphone</th>
                    <td><?= $user->telephone ?></td>
                </tr>
                <tr>
                    <th scope="row">Date de naissance</th>
                    <td><?= $user->date_naissance ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
