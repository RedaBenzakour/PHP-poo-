<div class="container mt-5">
    <h1>Liste d'articles dans mon panier</h1>
 
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Image</th>
                <th scope="col">Nom</th>
                <th scope="col">Prix</th>
                <th scope="col">Quantite</th>
                <th scope="col">Courte Description</th>
                <th scope="col">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($parfums as $key => $valueParfum): ?>
                <?php
                $parfum = $valueParfum[0];
                $quantite = $valueParfum[1];
                ?>
                <tr>
                    <th scope="row"><?= $key + 1; ?></th>
                    <td>
                        <img height="100px" width="100px" src="<?= isset($parfum->chemin_image) ? URI . $parfum->chemin_image : URI . 'assets/image.jpeg'; ?>">
                    </td>
                    <td><?= isset($parfum->nom) ? $parfum->nom : 'N/A'; ?></td>
                    <td><?= isset($parfum->prix) ? $parfum->prix : 'N/A'; ?></td>
                    <td>
                        <input name="quantite" min="0" max="<?= isset($parfum->quantite) ? $parfum->quantite : '0'; ?>" value="<?= isset($quantite) ? $quantite : '0'; ?>" type="number">
                    </td>
                    <td><?= isset($parfum->courte_description) ? $parfum->courte_description : 'N/A'; ?></td>
                    <td class="row">
                        <?php if (isset($_SESSION['Utilisateur'])): ?>
                            <?php if ($_SESSION['Utilisateur']->id_role == 1): ?>
                                <form action="<?= URI . 'paniers/modifier/' . $parfum->id_parfum; ?>" method="post">
                                    <button type="submit" class="btn btn-sm btn-warning col">
                                        <i class="bi bi-pencil-square"></i>
                                    </button>
                                </form>
                            <?php endif; ?>
                            <a class="btn btn-sm btn-danger col" href="<?= URI . 'paniers/supprimer/' . $parfum->id_parfum; ?>">
                                <i class="bi bi-trash3-fill"></i>
                            </a>
                        <?php else: ?>
                            <div class="col">
                                Veuillez vous connecter pour payer
                            </div>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
        <tr>
            <th colspan="5">Total Price</th>
            <th><?= $totalPrice; ?> $</th>
        </tr>
    </tfoot>
</table>

    </table>
    <?php if (isset($_SESSION['Utilisateur'])): ?>
        <div id="paypal-button-container"></div> <!-- Container for the PayPal button -->
        <h2>Payment Details</h2>
    <form action="<?= URI . 'paniers/payer'; ?>" method="post">
        <div class="mb-3">
            <label for="cardNumber" class="form-label">Card Number</label>
            <input type="text" class="form-control" id="cardNumber" name="cardNumber" required>
        </div>
        <div class="mb-3">
            <label for="expiryDate" class="form-label">Expiry Date</label>
            <input type="month" class="form-control" id="expiryDate" name="expiryDate" required>
        </div>
        <div class="mb-3">
            <label for="cvv" class="form-label">CVV</label>
            <input type="text" class="form-control" id="cvv" name="cvv" required>
        </div>
        <button type="submit" class="btn btn-primary">Pay Now</button>
    </form>
    <?php endif; ?>
</div>
 
<?php if (isset($_SESSION['Utilisateur'])): ?>
    <script src="https://www.paypal.com/sdk/js?client-id=AcWpdxxztnbYmSiSlKWwxDjjq3Mxr3OE0hkgPGtOjYr-5QrHPKS8JQ6syyTe6vDr2y-Rst4lFs-hJqRU&components=buttons"></script>
    <script>
    paypal.Buttons({
        createOrder: function(data, actions) {
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        value: '0.01' // Test with a simple transaction value
                    }
                }]
            });
        },
        onApprove: function(data, actions) {
        return actions.order.capture().then(function(details) {
            var formData = new FormData();
            formData.append('orderID', data.orderID); // Et tous les autres champs nécessaires

            fetch('<?= URI . "commandes/ajouterCommande"; ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert('Transaction completed by ' + details.payer.name.given_name);
                })
            .catch(error => {
                console.error('Error:', error);
                // Gestion des erreurs ici
            });
        });
    }
}).render('#paypal-button-container');
    </script>
<?php endif; ?>