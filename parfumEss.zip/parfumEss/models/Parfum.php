<?php

class Parfum extends Model
{
    public function __construct()
    {
        parent::__construct();
        $this->table = "Parfum";
    }

    public function ajouter($data)
    {
        $this->sql = "insert into " . $this->table . " (nom, prix, description, courte_description, quantite) 
                        VALUE (:nom, :prix, :description, :courte_description, :quantite)";
        return $this->getLines($data, null);
    }
    
    public function getLastInsertId() {
        return $this->db->lastInsertId();
    }
    

    public function getParfums()
    {
        $this->sql = "select f.*,i.chemin_image from " . $this->table . " 
        f left JOIN Image i on f.id_parfum = i.id_parfum;";
        return $this->getLines();
    }

    public function supprimer($id_parfum) {
        // First, delete related images to prevent foreign key constraint violation
        $this->sql = "DELETE FROM Image WHERE id_parfum = :id_parfum";
        $this->getLines(['id_parfum' => $id_parfum], null);
    
        // Now, it's safe to delete the film
        $this->sql = "DELETE FROM " . $this->table . " WHERE id_parfum = :id_parfum";
        return $this->getLines(['id_parfum' => $id_parfum], null);
    }
    


    public function getOneById($id_parfum) {
        $this->sql = "SELECT f.*, i.chemin_image FROM " . $this->table . " f 
                      LEFT JOIN Image i ON f.id_parfum = i.id_parfum WHERE f.id_parfum = :id_parfum";
    
        // Ensure you pass an associative array with keys that match the SQL placeholders
        return $this->getLines(array('id_parfum' => $id_parfum), true);
    }
    

    public function mettreAJour($id_parfum, $data) {
        // Add the id_film to the $data array
        $data['id_parfum'] = $id_parfum;
    
        $this->sql = "UPDATE " . $this->table . " SET 
            nom = :nom, 
            prix = :prix, 
            description = :description, 
            courte_description = :courte_description, 
            quantite = :quantite 
            WHERE id_parfum = :id_parfum";

    
        // The $data array now should have all the necessary keys for binding
        return $this->getLines($data, null);
    }
    
    public function updateImagePath($id_parfum, $imagePath) {
        // Check if an image already exists for the film
        $this->sql = 'SELECT * FROM Image WHERE id_parfum = :id_parfum';
        $existingImage = $this->getLines(['id_parfum' => $id_parfum], true);
    
        if ($existingImage) {
            // Image exists, update it
            $this->sql = "UPDATE Image SET chemin_image = :chemin_image WHERE id_parfum = :id_parfum";
            return $this->getLines(['chemin_image' => $imagePath, 'id_parfum' => $id_parfum], null);
        } else {
            // No image exists, insert a new one
            $this->sql = "INSERT INTO Image (id_parfum, chemin_image) VALUES (:id_parfum, :chemin_image)";
            return $this->getLines(['chemin_image' => $imagePath, 'id_parfum' => $id_parfum], null);
        }
    }
    
    


}