
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
            crossorigin="anonymous"></script>
    <title>Profil Utilisateur</title>
    <style>
        
        /* Global page styling */
        body {
            padding-top: 140px; /* Adds space between the navbar and the page content */
        }

        /* Navbar styling */
        .navbar {
            background-color: black !important;
            justify-content: space-between; /* Ensures space around items */
            font-family: Georgia, serif;
        }
        .navbar-brand, .nav-link {
        color: white !important;
        text-decoration: none !important; /* Ensures no underline normally */
        font-size: 1.2rem; /* Increases the font size */
        transition: transform 0.3s ease, color 0.3s ease; /* Smooth transition for hover effects */
    }
    .navbar-brand:hover, .nav-link:hover {
        color: grey !important;
        text-decoration: underline !important; /* Restores underline on hover */
        text-underline-offset: 6px; /* Keeps the space between text and underline */
        transform: scale(1.1); /* Slightly enlarge the links on hover */
    }

    /* Navbar nav adjustment to keep links centered */
    .navbar-nav {
        flex-grow: 1; /* Allows nav to take up as much space as needed */
        justify-content: center; /* Ensures links remain centered */
    }

    /* Cart icon style adjustments */
    .cart-icon {
        display: flex;
        align-items: center;
        color: white; /* Color for the cart icon and number */
        font-size: 1.5rem; /* Increase the size of the cart icon */
        text-decoration: none !important; /* No underline */
        transition: all 0.3s ease; /* Smooth transition for hover effects */
    }
    .cart-icon:hover {
        color: #ddd; /* Lighter grey color on hover */
        transform: scale(1.1); /* Slightly enlarge the cart icon on hover */
    }
    .cart-icon i {
        margin-right: 5px; /* Spacing between cart icon and item count */
    }

    /* Cart item count style adjustments */
    .cart-count {
        background-color: #ff4500; /* Bright color for visibility */
        color: white;
        border-radius: 50%; /* Rounded shape for the count */
        padding: 2px 8px; /* Padding inside the count bubble */
        font-size: 0.9rem; /* Smaller font size for the count */
        margin-left: -8px; /* Adjust alignment of the count bubble */
        position: relative;
        top: -10px; /* Position the count bubble slightly above the cart icon */
        transition: all 0.3s ease; /* Smooth transition for hover effects */
    }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="/dashboard/projets/parfumEss/about.php">
            <img  src="/dashboard/projets/parfumEss/assets/images/logo.webp" alt="Essencia Parfumos Logo" style="height: 80px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?= URI . 'index'; ?>">Home</a>
                </li>
                <?php if (!isset($_SESSION['Utilisateur'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= URI . 'auths/connexion'; ?>">Connexion</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= URI . 'auths/inscription'; ?>">Inscription</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= URI . 'utilisateurs/profile'; ?>">Profil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?= URI . 'auths/deconnexion'; ?>">Déconnexion</a>
                    </li>
                <?php endif; ?>
            </ul>
            <?php if (!(isset($_SESSION['Utilisateur']) && $_SESSION['Utilisateur']->id_role == 1)): ?>
                <a class="cart-icon btn btn-link" href="<?= URI . 'paniers/index'; ?>">
                    <i class="bi bi-cart3"></i>
                    <?= isset($_SESSION['Paniers']) ? count($_SESSION['Paniers']) : 0; ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>
</body>
</html>
