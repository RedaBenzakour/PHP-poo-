<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Compact Registration Form</title>
<style>
  .container {
    max-width: 400px; /* Reduces the width of the form */
    margin: 50px auto; /* Centers the form vertically and horizontally */
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Adds a subtle shadow around the form */
  }
  .form-control {
    width: 100%;
    margin-bottom: 10px; /* Reduces space between inputs */
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  .btn-primary {
    width: 100%;
    background-color: #007BFF;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  .btn-primary:hover {
    background-color: #0056b3;
  }
  label {
    display: block;
    margin-bottom: 5px;
  }
</style>
</head>
<body>
<form method="post" class="container">
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nom: </label>
    <input type="text" class="form-control" name="nom">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Prenom:</label>
    <input type="text" class="form-control" name="prenom">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Email:</label>
    <input type="email" class="form-control" name="email">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Date de naissance:</label>
    <input type="date" class="form-control" name="date_naissance">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Telephone</label>
    <input type="text" class="form-control" name="telephone">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Mot de passe:</label>
    <input type="password" class="form-control" name="mot_de_passe">
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Confirmer mot de passe:</label>
    <input type="password" class="form-control" name="c_mot_de_passe">
  </div>
  <input type="submit" class="btn btn-primary" name="submit" value="Enregistrer">
</form>