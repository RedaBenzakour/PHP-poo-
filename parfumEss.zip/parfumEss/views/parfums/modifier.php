<div class="container mt-5">
    <h2>Modifier Product</h2>
    <form method="post" enctype="multipart/form-data" action="<?= URI . 'parfums/mettreAJour/' . $parfum->id_parfum; ?>">
        <div class="form-group">
            <label for="productName">Title :</label>
            <input
                type="text"
                class="form-control"
                id="nom"
                name="nom"
                value="<?= $parfum->nom; ?>" 
                required
            />
        </div>
        <div class="form-group">
            <label for="productShortDescription">Parfum Short Description :</label>
            <input
                type="text"
                class="form-control"
                id="courte_description"
                name="courte_description"
                value="<?= $parfum->courte_description; ?>" 
                required
            />
        </div>
        <div class="form-group">
            <label for="productPrice">Parfum Price : </label>
            <input
                type="text"
                class="form-control"
                id="parfumPrice"
                name="prix"
                value="<?= $parfum->prix; ?>" 
                required
            />
        </div>
        <div class="form-group">
            <label for="productQuantity">Parfum Quantity : </label>
            <input
                type="text"
                class="form-control"
                id="parfumQuantity"
                name="quantite"
                value="<?= $parfum->quantite; ?>" 
                required
            />
        </div>
        <div class="form-group">
            <label for="productDescription">Parfum Description :</label>
            <input
                type="text"
                class="form-control"
                id="parfumDescription"
                name="description"
                value="<?= $parfum->description; ?>" 
                required
            />
        </div>
        <div class="form-group">
            <label for="image" class="form-label">Choose an Image :</label>
            <input type="file" name="image" id="image" />
            <!-- If there is an existing image, show it -->
            <?php if (isset($parfum->chemin_image)): ?>
                <img src="<?= URI . $parfum->chemin_image; ?>" alt="Current Image" height="100">
            <?php endif; ?>
        </div>
        <!-- The submit button text should be 'Update Product' -->
        <input type="submit" name="submit" class="btn btn-primary" value="Update Product">
    </form>
</div>
