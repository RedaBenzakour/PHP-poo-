<?php

class Parfums extends Controllers {
    private $parfumModel;

    public function __construct() {
        parent::__construct(); // Make sure that parent's constructor is called if it's necessary.
        $this->parfumModel = new Parfum(); // Instantiate the Parfum model.
    }
    
    public function index() {
        $parfums = $this->parfumModel->getParfums(); // Use already instantiated model
        $this->render("index", compact('parfums'));
    }

    /**
     * @return void
     */
    public function ajouter() {
        if (isset($_SESSION['Utilisateur']) && strtolower($_SESSION['Utilisateur']->description) === Auth::ADMIN) {
            global $oPDO; // Accéder à la connexion PDO globale
           
            if (isset($_POST['submit'])) {
                unset($_POST['submit']);
                if (!$this->estVide($_POST)) {
                    $this->parfumModel->ajouter($_POST);
                    $id_parfum = $oPDO->lastInsertId(); // Utiliser la connexion PDO globale
                    $this->telechargerImage($id_parfum);
                }
                header("Location: " . URI . "parfums/index");
                exit;
            }
            $this->render('ajouter');
        } else {
            header("Location: " . URI . "parfums/index");
            exit;
        }
    }
    /**
     * @param $id_parfum
     * @return void
     */
    private function telechargerImage($id_parfum) {
        if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
            $image_name = $_FILES["image"]["name"];
            $image_tmp = $_FILES["image"]["tmp_name"];
            $image_destination = "assets/images/" . basename($image_name); // Destination path on the server
    

            $image_type = strtolower(pathinfo($image_destination, PATHINFO_EXTENSION));

            if (!in_array($image_type, array("jpg", "jpeg", "png", "gif"))) {
                echo "Seules les images JPG, JPEG, PNG et GIF sont autorisées.";
                exit();
            }
            if (move_uploaded_file($image_tmp, ROOT . $image_destination)) {
                $this->parfumModel->updateImagePath($id_parfum, $image_destination);
            }
        }
    }

    public function supprimer($id_parfum)
{
    if (is_numeric($id_parfum)) {
        // First, delete the item from the database
        $this->parfumModel->supprimer($id_parfum);

        // Remove the item from users' carts
        $panierModel = new Panier();
        $panierModel->supprimer($id_parfum);

        // Redirect or return a success message
        header('Location: ' . URI . 'parfums/index?success=deleted');
        exit;
    } else {
        // Redirect with an error message for invalid ID
        header('Location: ' . URI . 'parfums/index?error=invalidid');
        exit;
    }
}

    // Modifier method
    public function modifier($id_parfum) {
        // Logic to fetch the parfum and display the edit form
        $parfum = $this->parfumModel->getOneById($id_parfum); // Ensure this method exists in the Parfum model
        $this->render('modifier', ['parfum' => $parfum]);
    }

    public function mettreAJour($id_parfum) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Filter out the submit button from the POST data
            $updatedParfumData = $_POST;
            unset($updatedParfumData['submit']);
    
            if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
                $this->telechargerImage($id_parfum);
            }
    
            // Now, update the parfum details in the database
            $this->parfumModel->mettreAJour($id_parfum, $updatedParfumData);
    
            header('Location: ' . URI . 'parfums/index');
            exit;
        } else {
            header('Location: ' . URI . 'parfums/modifier/' . $id_parfum);
            exit;
        }
    }
    
}


?>