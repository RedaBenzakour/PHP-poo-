<!DOCTYPE html>
<html lang="fr">
<head>
    <style>
        /* Footer styling */
        .footer {
            background-color: black;
            color: white;
            text-align: center;
            padding: 5px 0; /* Reduce padding top and bottom */
            width: 100%;
            font-size: 14px;
           
            bottom: 0;
            left: 0; /* Make sure the footer aligns with the left side */
            z-index: 1000; /* Ensure footer stays on top */
        }

        /* Footer links */
        .footer a {
            color: white;
            text-decoration: none;
            margin: 0 5px; /* Reduce margin */
            transition: all 0.3s ease; /* Add smooth transition for hover effect */
        }

        /* Hover effect for footer links */
        .footer a:hover {
            color: grey;
            text-decoration: underline;
        }

        /* Social icons */
        .social-icons {
            margin-top: 5px; /* Reduce margin top */
        }

        /* Style adjustments for social media icons */
        .social-icons img {
            width: 20px; /* Adjust icon size */
            margin: 0 5px; /* Reduce margin */
            transition: all 0.3s ease; /* Add smooth transition for hover effect */
        }

        /* Hover effect for social media icons */
        .social-icons img:hover {
            transform: scale(1.1); /* Enlarge icon on hover */
        }
    </style>
</head>
<body>

<footer class="footer">
    <p>
        <a href="#">Mentions légales</a> |
        <a href="#">Politique de confidentialité</a> |
        <a href="#">Conditions générales de vente</a>
        <p>© <?= date("Y"); ?> ParfumShop. Tous droits réservés.</p>
    </p>
    <div class="social-icons">
        Suivez-nous :
        <a href="https://www.facebook.com" target="_blank"><img src="/dashboard/projets/parfumEss/assets/images/fb.png" alt="Facebook"></a>
        <a href="https://www.instagram.com" target="_blank"><img src="/dashboard/projets/parfumEss/assets/images/ig.png" alt="Instagram"></a>
        <a href="https://www.whatsapp.com" target="_blank"><img src="/dashboard/projets/parfumEss/assets/images/whatsapp.png" alt="Contact us"></a>
    </div>
</footer>

</body>
</html>
