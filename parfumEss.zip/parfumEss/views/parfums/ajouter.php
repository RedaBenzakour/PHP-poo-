<div class="container mt-5">
    <h2>Add Product</h2>
    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="productName">Title :</label>
            <input
                type="text"
                class="form-control"
                id="nom"
                name="nom"
                required
            />
        </div>
        <div class="form-group">
            <label for="productName">Parfum Short Description :</label>
            <input
                type="text"
                class="form-control"
                id="courte_description"
                name="courte_description"
                required
            />
        </div>
        <div class="form-group">
            <label for="productPrice">Parfum Price : </label>
            <input
                type="text"
                class="form-control"
                id="parfumPrice"
                name="prix"
                required
            />
        </div>
        <div class="form-group">
            <label for="productPrice">Parfum Quantity : </label>
            <input
                type="text"
                class="form-control"
                id="parfumQuantity"
                name="quantite"
                required
            />
        </div>
        <div class="form-group">
            <label for="productName">Parfum Description :</label>
            <input
                type="text"
                class="form-control"
                id="parfumName"
                name="description"
                required
            />
        </div>
        <div class="form-group">
            <label for="image" class="form-label">Choose an Image :</label>
            <input type="file" name="image" id="image" />
        </div>
        <input type="submit" name="submit" class="btn btn-primary" value="Add Product">

    </form>
</div>