drop database if exists ParfumShop;
create database Parfumshop;
use Parfumshop;
create table Utilisateur
(
    id_utilisateur int primary key auto_increment,
    nom            varchar(100) not null,
    prenom         varchar(100),
    email          varchar(255) not null unique,
    telephone      varchar(20),
    date_naissance date,
    id_role        int,
 
    mot_de_passe   text         not null
 
 
);
 
create table Role
(
    id_role     int primary key auto_increment,
    description varchar(100) not null
 
);
 
create table Adresse
(
    id_adresse  int primary key auto_increment,
    rue         varchar(100) not null,
    ville       varchar(100) not null,
    code_postal varchar(10)  not null,
    province    varchar(100) not null,
    defaut      int
);
 
create table AdresseUtilisateur
(
    id_utilisateur int,
    id_adresse     int
);
 
create table Parfum
(
    id_parfum            int auto_increment primary key,
    nom                varchar(100) not null,
    prix               varchar(10)  not null,
    description        text,
    courte_description varchar(255),
    quantite           int
);
 
create table Image
(
    id_image     int primary key auto_increment,
    id_parfum      int,
    chemin_image text
);
 
create table ParfumCommande
(
    id_parfum    int,
    id_commande int,
    quantite    int
);
 
create table Commande
(
    id_commande    int primary key auto_increment,
    quantite       int,
    prix           varchar(10),
    statut         varchar(50),
    date_creation  date,
    id_utilisateur int,
    mode_paiement  varchar(50)
 
);
 
# relation
alter table AdresseUtilisateur
    add constraint fk_adresse_utilisateur
        foreign key (id_adresse) references Adresse (id_adresse)
            on update cascade,
    add constraint fk_utilisateur_adresse
        foreign key (id_utilisateur) references Utilisateur (id_utilisateur)
            on delete cascade on update cascade;
 
alter table ParfumCommande
    add constraint fk_parfum_commande
        foreign key (id_parfum) references Parfum (id_parfum),
    add constraint fk_commande_parfum
        foreign key (id_commande) references Commande (id_commande);
 
alter table Image
    add constraint fk_image_parfum
        foreign key (id_parfum) references Parfum (id_parfum);
 
alter table Utilisateur
    add constraint fk_role_utilisateur
        foreign key (id_role) references Role (id_role);
 
insert into Role(description) value ('admin'),('client');
 
 
 