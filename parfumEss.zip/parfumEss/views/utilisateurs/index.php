<!-- utilisateurs/index.php -->

<div class="container mt-5">
    <h1>Liste d'Utilisateurs</h1>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Nom</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($utilisateurs as $utilisateur): ?>
            <tr>
                <td><?= $utilisateur->id_utilisateur; ?></td>
                <td><?= $utilisateur->nom; ?></td>
                <td><?= $utilisateur->email; ?></td>
                <td>
                    <a href="<?= URI . 'utilisateurs/modifier/' . $utilisateur->id_utilisateur; ?>" class="btn btn-warning">Modifier</a>
                    <a href="<?= URI . 'utilisateurs/supprimer/' . $utilisateur->id_utilisateur; ?>" class="btn btn-danger">Supprimer</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
