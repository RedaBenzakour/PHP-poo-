<div class="container mt-5">
    <h1>Liste d'articles</h1>

    <?php if (isset($_SESSION['Utilisateur']) && $_SESSION['Utilisateur']->id_role == 1): ?>
        <div class="btn-group mb-3">
            <a class="btn btn-primary" href="<?= URI . 'parfums/ajouter' ?>">Ajouter</a>
        </div>
    <?php endif; ?>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Image</th>
            <th scope="col">Nom</th>
            <th scope="col">Prix</th>
            <th scope="col">Quantite</th>
            <th scope="col">Courte Description</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $cmpt = 1; foreach ($parfums as $parfum): ?>
            <tr>
                <th scope="row"><?= $cmpt++; ?></th>
                <td>
                    <img height="100px" width="100px" src="<?= isset($parfum->chemin_image) ? URI . $parfum->chemin_image : URI . 'assets/image.jpeg'; ?>">
                </td>
                <td><?= $parfum->nom; ?></td>
                <td><?= $parfum->prix; ?></td>
                <td><?= $parfum->quantite; ?></td>
                <td><?= $parfum->courte_description; ?></td>
                <td>
                <?php 
                    if (!(isset($_SESSION['Utilisateur']) && $_SESSION['Utilisateur']->id_role == 1)): ?>
                        <a class="btn btn-sm btn-success" href="<?= URI . 'paniers/ajouter/' . $parfum->id_parfum; ?>">Ajouter panier</a>
                    <?php endif; ?>
                    <?php if (isset($_SESSION['Utilisateur']) && $_SESSION['Utilisateur']->id_role == 1): ?>
                        <a class="btn btn-sm btn-warning" href="<?= URI . 'parfums/modifier/' . $parfum->id_parfum; ?>"><i class="bi bi-pencil-square"></i></a>
                        <a class="btn btn-sm btn-danger" href="<?= URI . 'parfums/supprimer/' . $parfum->id_parfum; ?>"><i class="bi bi-trash"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
