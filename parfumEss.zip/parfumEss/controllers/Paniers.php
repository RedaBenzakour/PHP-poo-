<?php

class Paniers extends Controllers
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
{
    $panier = new Panier();
    $parfums = $panier->getAll();
    $totalPrice = $panier->getTotalPrice();  // Calculate the total price
    $this->render('index', compact('parfums', 'totalPrice'));
}


    public function test($data)
    {
        echo $data;
//        echo "Je suis test";

    }

    public function ajouter($id_parfum)
    {
        if (is_numeric($id_parfum)) {
            $panier = new Panier();
            $panier->ajouter($id_parfum, 1);
        }
        header('Location: ' . URI . 'parfums/index');


    }

    public function modifier($id_parfum)
    {
        if (is_numeric($id_parfum)) {
            $quantite = $_POST['quantite'];
            if (is_numeric($quantite)) {
                $panier = new Panier();
                $panier->ajouter($id_parfum, $quantite);
            }
        }
        header("Location: " . URI . "paniers/index");

    }

    public function supprimer($id_parfum)
    {
        if (is_numeric($id_parfum)) {
            $panier = new Panier();
            $panier->supprimer($id_parfum);
        }
        header("Location: " . URI . "paniers/index");
    }

}