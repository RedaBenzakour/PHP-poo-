<?php

class Auths extends Controllers
{
    public function inscription()
    {

        if (isset($_SESSION['Utilisateur'])) {
            header("Location: " . URI . "parfums/index");
        }
        if (isset($_POST["submit"])) {
            if (!($this->estVide($_POST))) {
                if ($_POST["mot_de_passe"] === $_POST["c_mot_de_passe"]) {
                    $_POST["mot_de_passe"] = password_hash($_POST["mot_de_passe"], PASSWORD_DEFAULT);

                    unset($_POST["c_mot_de_passe"]);
                    unset($_POST["submit"]);
                    $_POST["id_role"] = 2;

                    $oAuth = new Auth();
                    $oAuth->inscription($_POST);


                }

            }

        }
        $this->render("register");
    }

    public function connexion()
    {
        if (isset($_SESSION['Utilisateur'])) {
            header("Location: " . URI . "parfums/index");
        }
        if (isset($_POST['submit'])) {
            if (!$this->estVide($_POST)) {
                $mot_de_passe = $_POST["mot_de_passe"];
                unset($_POST["mot_de_passe"], $_POST["submit"]);
                $auth = new Auth();
                $user = $auth->findUserByEmail($_POST);
                if ($user) {
                    if (password_verify($mot_de_passe, $user->mot_de_passe)) {
                        $_SESSION["Utilisateur"] = $user;
                        header("Location: " . URI . "parfums/index");

                    } else {
                        $this->erreurs["emPass"] = "Email or password incorrect";
                        $this->render('login', $this->erreurs);

                    }
                } else {
                    $this->erreurs["emPass"] = "Email or password incorrect";
                    $this->render('login', $this->erreurs);
                }
            } else {
                $this->erreurs["emPass"] = "Email or password incorrect";
                $this->render('login', $this->erreurs);
            }

        }
        $this->render('login');
    }

    public function index()
    {
        if (!isset($_COOKIE["toto"])) {
            setcookie("toto", "Toto est là!", time() + (60 * 60 * 24));
        }
        echo "Je suis a index";

        var_dump($_SESSION["utilisateur"]);
    }

    public function deconnexion()
    {
        // fermeture de la session
        unset($_SESSION['Utilisateur']);

        // retour vers la page films/index
        header("Location: " . URI . "parfums/index");
    }
    
    // public function profile() {
    //     $userModel = new Utilisateur();
    //     $user = $userModel->getUserById($_SESSION['Utilisateur']->id_utilisateur);

    //     // Vérifiez que les informations utilisateur sont toujours à jour
    //     $_SESSION['Utilisateur'] = $user;

    //     // Render the profile view with the user data
    //     $this->render('profile', ['user' => $user]);
    // }
}


?>